import { When, Then} from '@wdio/cucumber-framework';

import BorrowingCalculator from '../pageobjects/BorrowingCalculator.page';
import page from '../pageobjects/page';

When(/^User on Calculator page$/, async () => {
    page.url();

   // await expect(BorrowingCalculator.pagetitle).toBePresent();
    BorrowingCalculator.titlepage();

});

Then(/^Application type$/, async () => {
    BorrowingCalculator.single();
});

Then(/^No of Dependents$/, async () => {
    BorrowingCalculator.dependents();
});

Then(/^Property you would like to buy$/, async() => {
    BorrowingCalculator.hometoLive();
});

Then(/^Provide ([^"]*) Your annual income$/, async (annualincome) => {
    BorrowingCalculator.annualIn(annualincome);
});

Then(/^Provide ([^"]*) Your annual other income$/, async(otherincome) => {
    BorrowingCalculator.otherIn(otherincome);
});

Then(/^Monthly living ([^"]*)$/, async(montlyLiving) => {
    BorrowingCalculator.monthlyExp(montlyLiving);
});

Then(/^Provide ([^"]*) Current home loan monthly repayments$/, async(homeLoan) => {
    BorrowingCalculator.homeLn(homeLoan);
});









Then(/^Provide ([^"]*) Other loan monthly repayments$/, async(otherLoan) => {
    BorrowingCalculator.otherLo(otherLoan);
});

Then(/^Provide ([^"]*) Other monthly commitments$/, async(commitments) => {
    BorrowingCalculator.committs(commitments);
});

Then(/^Provide ([^"]*) Total credit card limits$/, async(ccLimits) => {
    BorrowingCalculator.cclimit(ccLimits);
});

Then(/^Click on Work out how much I could borrow button$/, async() => {
    BorrowingCalculator.borrow();
});

Then(/^Click on Start over$/, async() => {
    BorrowingCalculator.restart();
});