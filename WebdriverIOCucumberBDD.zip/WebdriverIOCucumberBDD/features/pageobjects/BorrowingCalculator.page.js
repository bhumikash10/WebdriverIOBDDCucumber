
import Page from './page';

class BorrowingCalculator {
//WebElements
   get pagetitle() {
       return $(".primary grid clearfix");
   } 

   // Application type Single
    get btnSingle() {
        return $("#application_type_single");
    }

//No of dependents

    get noOfdependents() { 
        return $('//*[@title="Number of dependants"]');
    
    }
 // Home to live in
        get homeTo() {
            return $('//*[@id="borrow_type_home"]');
        }
//Your annual income
get annual_Income() {
    return $('//*[@aria-labelledby="q2q1"]');
}

//other income
   get other_Income() {
       return $('//*[@aria-labelledby="q2q2"]');
   }

//Monthly living expenses 
   get monthly_expenses() {
    return $('//*[@id="expenses"]');
}
//Current home loan monthly repayments 
    get home_Loan() {
        return $('//*[@aria-labelledby="q3q2"]');
    }


//Other loan monthly repayments 
get other_Loan() {
    return $('//*[@aria-labelledby="q3q3"]');
}
//Other monthly commitments
get commitments() {
    return $('//*[@aria-labelledby="q3q4"]');
}
//Total CC limits
 get creditclimits() {
     return $('//*[@id="credit"]');
 }
//borrow button
 get btnborrow() {
     return $('//*[@id="btnBorrowCalculater"]');
 }
//Restart
 get btnrestart() {
     return $('//*[@class="result__restart"] /button[@role="button"]');
 }


//Actions

   async titlepage() {
       console.log("titlename");

   }
   //Application type single
   async single() {
    (await this.btnSingle).waitForExist({ timeout: 5000 });

       await this.btnSingle.click();
   }
 //No of dependents

    async dependents() {
        await this.noOfdependents.click();
        await this.noOfdependents.selectByIndex(0);       
    }
 
// Home to live in 
    async hometoLive() {
        await this.homeTo.click();
    }

//Your annual income
    async annualIn(annualincome) {
        await this.annual_Income.click();
        await this.annual_Income.setValue(annualincome);
    }
// Other income
    async otherIn(otherincome) {
        (await this.other_Income).waitForExist({timeout: 5000});
        (await this.other_Income).setValue(otherincome);
    }
// Monthly living expenses 
async monthlyExp(montlyLiving) {
    await this.monthly_expenses.click();
    await this.monthly_expenses.setValue(montlyLiving);
}

//Current home loan monthly repayments 
async homeLn(homeLoan) {
    await  this.home_Loan.click();
    await  this.home_Loan.setValue(homeLoan);
}
// Other Loan 
async otherLo(otherLoan) {
    await  this.other_Loan.click();
    await  this.other_Loan.setValue(otherLoan);
}

// Other monthly commitments
async committs(commitments) {
    await this.commitments.click();
    await this.commitments.setValue(commitments);
}
// Total credit card limit
async cclimit(ccLimits) {
    (await this.creditclimits).click();
    (await this.creditclimits).setValue(ccLimits);
}
//borrow button
async borrow() {
     (await this.btnborrow).click();
}

//Restart
async restart() {
    (await this.btnrestart).click();
}

}

export default new BorrowingCalculator();