class browserUrl{
url() {
   

         browser.url("https://www.anz.com.au/personal/home-loans/calculators-tools/much-borrow");
         browser.maximizeWindow()

         console.log("Navigated to web page");
         browser.pause(5000);
    }
}
export default new browserUrl();
